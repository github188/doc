﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o),_(c,p,e,f,g,q,i,[_(c,r,e,f,g,s),_(c,t,e,f,g,u),_(c,v,e,f,g,w),_(c,x,e,f,g,y)])])]);}; 
var b="rootNodes",c="pageName",d="行情",e="type",f="Wireframe",g="url",h="行情.html",i="children",j="首页",k="首页.html",l="自选",m="自选.html",n="分时\/k线",o="分时_k线.html",p="交易",q="交易.html",r="委托",s="委托.html",t="查询",u="查询.html",v="转账",w="转账.html",x="辅助",y="辅助.html";
return _creator();
})();
