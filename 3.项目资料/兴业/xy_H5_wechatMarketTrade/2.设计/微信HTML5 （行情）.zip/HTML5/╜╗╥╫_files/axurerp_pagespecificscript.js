﻿for(var i = 0; i < 49; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u34'] = 'top';