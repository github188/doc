﻿for(var i = 0; i < 67; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'center';
u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资买入.html');

}
});
gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u59'] = 'center';