﻿for(var i = 0; i < 149; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u146'] = 'center';gv_vAlignTable['u78'] = 'center';
u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u119'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u94'] = 'center';
$axure.eventManager.blur('u51', function(e) {

if ((GetWidgetText('u51')) == ('600000')) {

SetWidgetFormText('u52', '浦发银行');

;

;

}
});
gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u36'] = 'center';
$axure.eventManager.blur('u33', function(e) {

if ((GetWidgetText('u33')) == ('600000')) {

;

;

;

}
});
gv_vAlignTable['u104'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u142'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u130'] = 'center';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u113'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u136'] = 'center';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u100'] = 'center';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u126'] = 'center';gv_vAlignTable['u132'] = 'center';