﻿for(var i = 0; i < 83; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u59'] = 'center';
u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资买入.html');

}
});
