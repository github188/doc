﻿for(var i = 0; i < 44; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u28'] = 'top';
u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u34'] = 'top';