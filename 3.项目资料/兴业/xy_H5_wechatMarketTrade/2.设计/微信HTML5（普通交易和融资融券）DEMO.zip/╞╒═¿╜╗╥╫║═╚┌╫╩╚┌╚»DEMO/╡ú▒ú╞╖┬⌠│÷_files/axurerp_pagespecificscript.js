﻿for(var i = 0; i < 125; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u76'] = 'top';
u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u93'] = 'top';
u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'top';
u124.style.cursor = 'pointer';
$axure.eventManager.click('u124', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u91'] = 'top';