﻿for(var i = 0; i < 74; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u63'] = 'top';
u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u59'] = 'center';