﻿for(var i = 0; i < 130; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u119'] = 'center';
u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u126'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u52'] = 'center';
u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u44'] = 'top';
u74.style.cursor = 'pointer';
$axure.eventManager.click('u74', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u59'] = 'center';