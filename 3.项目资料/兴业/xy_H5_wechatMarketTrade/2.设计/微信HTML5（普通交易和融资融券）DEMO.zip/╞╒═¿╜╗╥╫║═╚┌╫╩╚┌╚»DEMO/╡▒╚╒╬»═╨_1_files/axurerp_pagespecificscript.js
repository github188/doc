﻿for(var i = 0; i < 52; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u43'] = 'top';
u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href="javascript:history.back()";

}
});
gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u31'] = 'top';