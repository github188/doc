﻿for(var i = 0; i < 81; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u27'] = 'center';
u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u19'] = 'center';
u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u37'] = 'top';
u80.style.cursor = 'pointer';
$axure.eventManager.click('u80', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u29'] = 'center';