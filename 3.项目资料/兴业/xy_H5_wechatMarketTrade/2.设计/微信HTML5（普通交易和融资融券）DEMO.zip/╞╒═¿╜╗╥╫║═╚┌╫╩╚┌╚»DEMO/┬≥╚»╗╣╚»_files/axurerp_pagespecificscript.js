﻿for(var i = 0; i < 179; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u168'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u108'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u176'] = 'center';gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u154'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u23'] = 'center';
u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u149'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u174'] = 'center';gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u99'] = 'center';
u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u156'] = 'center';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u160'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u139'] = 'center';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u130'] = 'center';gv_vAlignTable['u170'] = 'center';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u172'] = 'center';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u147'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u162'] = 'center';gv_vAlignTable['u141'] = 'center';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u145'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u178'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u93'] = 'center';gv_vAlignTable['u137'] = 'center';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u158'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u126'] = 'center';