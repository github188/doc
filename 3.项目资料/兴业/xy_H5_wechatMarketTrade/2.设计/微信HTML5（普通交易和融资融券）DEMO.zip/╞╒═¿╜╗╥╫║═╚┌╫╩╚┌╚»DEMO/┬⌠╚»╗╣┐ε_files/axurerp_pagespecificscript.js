﻿for(var i = 0; i < 144; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u23'] = 'center';
u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u125'] = 'top';gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u143'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u142'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u121'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u117'] = 'top';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u136'] = 'center';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u129'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u15'] = 'center';
u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u115'] = 'top';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u28'] = 'top';