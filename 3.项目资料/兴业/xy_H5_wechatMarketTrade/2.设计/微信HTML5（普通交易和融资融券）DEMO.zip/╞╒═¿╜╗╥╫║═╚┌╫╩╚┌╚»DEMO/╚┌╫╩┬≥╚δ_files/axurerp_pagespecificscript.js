﻿for(var i = 0; i < 113; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u20'] = 'center';
u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u105'] = 'center';
u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资标的券查询.html');

}
});
gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u58'] = 'top';
u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u29'] = 'center';