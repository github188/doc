﻿for(var i = 0; i < 154; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u37'] = 'center';
u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资标的券查询.html');

}
});
gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u119'] = 'center';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u94'] = 'top';
u99.style.cursor = 'pointer';
$axure.eventManager.click('u99', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u144'] = 'top';
u101.style.cursor = 'pointer';
$axure.eventManager.click('u101', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资标的券查询.html');

}
});
gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u121'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u130'] = 'center';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u3'] = 'top';
u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u147'] = 'top';
u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u141'] = 'top';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u153'] = 'top';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u148'] = 'top';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u126'] = 'center';