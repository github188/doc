﻿for(var i = 0; i < 263; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u224'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u207'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u222'] = 'top';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u159'] = 'center';gv_vAlignTable['u55'] = 'center';
$axure.eventManager.blur('u252', function(e) {

if ((GetWidgetText('u252')) == ('000856')) {

SetWidgetFormText('u254', '鞍钢股份');

;

}
});
gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u105'] = 'top';
u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if ((false) || (false)) {

;

}
else
if ((false) || (false)) {

;

}
else
if (true) {

}
});
gv_vAlignTable['u261'] = 'center';
u192.style.cursor = 'pointer';
$axure.eventManager.click('u192', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});

$axure.eventManager.blur('u241', function(e) {

if ((GetWidgetText('u241')) == ('000856')) {

SetWidgetFormText('u243', '鞍钢股份');

;

}
});
gv_vAlignTable['u259'] = 'center';gv_vAlignTable['u236'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u238'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u230'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u176'] = 'top';gv_vAlignTable['u184'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u164'] = 'top';gv_vAlignTable['u220'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u57'] = 'center';
u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u210'] = 'top';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u216'] = 'top';gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u182'] = 'top';
$axure.eventManager.blur('u249', function(e) {

if ((GetWidgetText('u249')) == ('000856')) {

SetWidgetFormText('u251', '鞍钢股份');

;

}
});
gv_vAlignTable['u226'] = 'top';
u144.style.cursor = 'pointer';
$axure.eventManager.click('u144', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u240'] = 'top';gv_vAlignTable['u180'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u244'] = 'top';gv_vAlignTable['u157'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u246'] = 'top';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u245'] = 'top';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u139'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u247'] = 'top';gv_vAlignTable['u228'] = 'top';gv_vAlignTable['u121'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u239'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u170'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u172'] = 'top';
$axure.eventManager.blur('u255', function(e) {

if ((GetWidgetText('u255')) == ('000856')) {

SetWidgetFormText('u257', '鞍钢股份');

;

}
});
gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u60'] = 'center';
u185.style.cursor = 'pointer';
$axure.eventManager.click('u185', function(e) {

if ((false) || (false)) {

;

}
else
if ((false) || (false)) {

;

}
else
if (true) {

}
});
gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u141'] = 'center';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u205'] = 'center';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u132'] = 'top';
u234.style.cursor = 'pointer';
$axure.eventManager.click('u234', function(e) {

if ((false) || (false)) {

;

}
else
if ((false) || (false)) {

;

}
else
if (true) {

}
});
gv_vAlignTable['u262'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u201'] = 'top';
u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u153'] = 'top';gv_vAlignTable['u178'] = 'top';gv_vAlignTable['u196'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u120'] = 'center';
u233.style.cursor = 'pointer';
$axure.eventManager.click('u233', function(e) {

if ((false) || (false)) {

;

}
else
if ((false) || (false)) {

;

}
else
if (true) {

}
});
gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u191'] = 'center';gv_vAlignTable['u193'] = 'top';gv_vAlignTable['u200'] = 'top';gv_vAlignTable['u199'] = 'top';gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u168'] = 'top';gv_vAlignTable['u248'] = 'top';gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u232'] = 'top';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u189'] = 'center';gv_vAlignTable['u218'] = 'top';gv_vAlignTable['u166'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u126'] = 'center';