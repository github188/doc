﻿for(var i = 0; i < 123; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u119'] = 'center';
u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u115'] = 'top';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u37'] = 'top';
u80.style.cursor = 'pointer';
$axure.eventManager.click('u80', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u121'] = 'center';