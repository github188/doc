﻿for(var i = 0; i < 122; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u27'] = 'top';
u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u121'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u99'] = 'center';
u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('融资融券主页.html');

}
});
gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u59'] = 'top';